from .employee_base import EmployeeBase


class Keeper(EmployeeBase):
    pass
